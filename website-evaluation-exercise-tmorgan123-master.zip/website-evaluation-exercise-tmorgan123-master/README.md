# WebsiteEvalEx
This is a preliminary exercise to help us all understand how we individually and collectively analyze and talk about web sites as makers.

## Brief
With a partner, identify an informational website (like a news site, magazine or trade publication) that you, as a user, think is strong and offers a good end user experience. Analyze that site with your partner from a "designer" or "maker" perspective and see if you can identify key decisions made by the design team and how those decisions impact the experience. What do you think the design team valued? Are there particular audiences focused on or overlooked?

## Required Specifications
* Must make a 2–3 minute presentation (no more than 3 minutes and no less than 2)
* Must show the site while presenting (can be screenshots or a walk-through)
* Must make presentation with a partner
* Must submit an outline for presentation as a .md file added to this repository
* Must fill in information below in this file and commit changes

///////// FILL IN THIS SECTION AND COMMIT CHANGES //////////
* Your Name: Tyler Morgan
* Your Partner's Name: Shanika Scarborough 
* URL of website analyzed: www.NY.gov
